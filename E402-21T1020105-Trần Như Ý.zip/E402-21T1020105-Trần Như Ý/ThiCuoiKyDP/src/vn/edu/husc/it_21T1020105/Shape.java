package vn.edu.husc.it_21T1020105;

public interface Shape {
	Shape taoBanSao();
	double getDienTich();
	String getThongTin();
}
