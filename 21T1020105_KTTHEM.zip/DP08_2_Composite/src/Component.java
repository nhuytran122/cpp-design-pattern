public interface Component {
	long getTotalSize();
	void editPath(String str);
	String getName();
}